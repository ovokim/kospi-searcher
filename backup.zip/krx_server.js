const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(__dirname));

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'stock_management_system_krx.html'));
});

const CACHE_FILE = path.join(__dirname, 'kospi_cache.json');
let cachedStocks = [];

function loadCache() {
    try {
        if (fs.existsSync(CACHE_FILE)) {
            const parsed = JSON.parse(fs.readFileSync(CACHE_FILE, 'utf8'));
            cachedStocks = parsed.stocks || [];
            console.log(`✓ 캐시 로드: ${cachedStocks.length}개 종목`);
        }
    } catch (e) {
        console.error('캐시 로드 실패:', e.message);
    }
}

function saveCache() {
    try {
        fs.writeFileSync(CACHE_FILE, JSON.stringify({
            stocks: cachedStocks,
            timestamp: Date.now()
        }, null, 2));
        console.log(`✓ 캐시 저장: ${cachedStocks.length}개 종목`);
    } catch (e) {
        console.error('캐시 저장 실패:', e.message);
    }
}

// 네이버 금융 시가총액 페이지 파싱
async function fetchNaverPage(page) {
    const url = `https://finance.naver.com/sise/sise_market_sum.naver?sosok=0&page=${page}`;
    const res = await fetch(url, {
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        }
    });
    if (!res.ok) return [];

    const buffer = await res.arrayBuffer();
    const html = new TextDecoder('euc-kr').decode(buffer);

    const stocks = [];
    // 네이버 고유 오타인 class="tltle" 매칭
    const rowRegex = /<a href="\/item\/main\.naver\?code=([0-9]{6})"[^>]*class="tltle"[^>]*>([\s\S]*?)<\/a>([\s\S]*?)<\/tr>/g;
    let match;

    while ((match = rowRegex.exec(html)) !== null) {
        const code = match[1];
        const name = match[2].trim();
        const trRest = match[3];

        // td.number 열 추출
        const tdMatches = [...trRest.matchAll(/<td[^>]*class="number"[^>]*>([\s\S]*?)<\/td>/g)]
            .map(m => m[1].replace(/<[^>]+>/g, '').replace(/,/g, '').trim());

        const parseNum = v => {
            if (!v || v === 'N/A' || v === '-') return null;
            const n = parseFloat(v);
            return isNaN(n) ? null : n;
        };

        // 네이버 기본 열 구조: 0:현재가, 4:시가총액(억), 8:PER, 9:ROE
        const price = parseNum(tdMatches[0]) || 0;
        const marketCap = parseNum(tdMatches[4]) || 0;
        const per = parseNum(tdMatches[8]);
        const roe = parseNum(tdMatches[9]);

        // PBR 산출 공식: PER * ROE / 100
        let pbr = null;
        if (per !== null && roe !== null && per > 0) {
            pbr = parseFloat(((per * roe) / 100).toFixed(2));
        }

        stocks.push({
            code,
            name,
            price,
            marketCap,
            per,
            roe,
            pbr,
            dividend: null
        });
    }
    return stocks;
}

// KOSPI 전종목(1~22페이지, 약 950개 종목) 수집
async function crawlAllKospi() {
    console.log('📡 네이버 금융에서 KOSPI 전종목 수집 중...');
    const promises = [];
    for (let p = 1; p <= 22; p++) {
        promises.push(fetchNaverPage(p));
    }
    const results = await Promise.all(promises);
    const all = results.flat();

    const map = new Map();
    all.forEach(s => map.set(s.code, s));
    cachedStocks = Array.from(map.values());

    saveCache();
    console.log(`✓ KOSPI ${cachedStocks.length}개 종목 지표 수집 완료!`);
    return cachedStocks;
}

app.post('/api/crawl', async (req, res) => {
    try {
        const stocks = await crawlAllKospi();
        res.json({ success: true, count: stocks.length, stocks });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// 조건 검색 엔드포인트
app.get('/api/search', (req, res) => {
    res.json({ success: true, count: cachedStocks.length, stocks: cachedStocks });
});

// DART 프록시
app.get('/api/dart/corpCode', async (req, res) => {
    try {
        const apiKey = req.query.crtfc_key;
        if (!apiKey) return res.status(400).send('API 키 필요');
        const dartRes = await fetch(`https://opendart.fss.or.kr/api/corpCode.xml?crtfc_key=${encodeURIComponent(apiKey)}`);
        const arrayBuffer = await dartRes.arrayBuffer();
        res.setHeader('Content-Type', 'application/zip');
        res.send(Buffer.from(arrayBuffer));
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.get('/api/dart/fnlttSinglIndx', async (req, res) => {
    try {
        const { crtfc_key, corp_code, bsns_year, reprt_code, idx_cl_code } = req.query;
        const params = new URLSearchParams({ crtfc_key, corp_code, bsns_year, reprt_code, idx_cl_code: idx_cl_code || 'M210000' });
        const dartRes = await fetch(`https://opendart.fss.or.kr/api/fnlttSinglIndx.json?${params}`);
        const data = await dartRes.json();
        res.json(data);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

loadCache();
app.listen(PORT, () => {
    console.log(`🚀 KOSPI 관리 서버 시작: http://localhost:${PORT}`);
});